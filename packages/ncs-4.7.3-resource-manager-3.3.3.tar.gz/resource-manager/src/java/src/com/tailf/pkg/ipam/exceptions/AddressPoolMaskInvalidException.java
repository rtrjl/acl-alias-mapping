package com.tailf.pkg.ipam.exceptions;

public class AddressPoolMaskInvalidException extends AddressPoolException {
    private static final long serialVersionUID = 0;

    public AddressPoolMaskInvalidException(String msg) {
        super(msg);
    }
}
