package com.tailf.pkg.testjunit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    ErrorCodeTest.class
})

public class ResourceManagerSuite {}
